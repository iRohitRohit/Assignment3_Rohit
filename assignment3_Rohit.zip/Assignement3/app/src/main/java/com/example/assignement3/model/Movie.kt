package com.example.assignement3.model

import java.io.Serializable

data class Movie(
    val id: String = "",
    val title: String = "",
    val genre: String = "",
    val year: Int = 0,
    val director: String = "",
    val studio: String = "",
    val rating: Double = 0.0,
    val posterUrl: String = "",
    var isFavorite: Boolean = false
) : Serializable
