package com.example.assignement3.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.assignement3.databinding.ActivityEditMovieBinding
import com.example.assignement3.model.Movie
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class EditMovieActivity : AppCompatActivity() {
    private lateinit var binding: ActivityEditMovieBinding
    private val db = FirebaseFirestore.getInstance()
    private val currentUserId = FirebaseAuth.getInstance().currentUser?.uid
    private var editingMovie: Movie? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditMovieBinding.inflate(layoutInflater)
        setContentView(binding.root)

        editingMovie = intent.getSerializableExtra("movie") as? Movie
        if (editingMovie != null) {
            title = "Edit Movie"
            binding.etTitle.setText(editingMovie!!.title)
            binding.etGenre.setText(editingMovie!!.genre)
            binding.etYear.setText(editingMovie!!.year.toString())
            binding.etRating.setText(editingMovie!!.rating.toString())
            binding.etPosterUrl.setText(editingMovie!!.posterUrl)
            binding.etStudio.setText(editingMovie!!.studio)

        } else {
            Toast.makeText(this, "Movie data not found", Toast.LENGTH_SHORT).show()
            finish()
        }

        binding.btnUpdate.setOnClickListener {
            val updatedMovie = editingMovie!!.copy(
                title = binding.etTitle.text.toString(),
                genre = binding.etGenre.text.toString(),
                year = binding.etYear.text.toString().toIntOrNull() ?: 0,
                rating = binding.etRating.text.toString().toDoubleOrNull() ?: 0.0,
                posterUrl = binding.etPosterUrl.text.toString(),
                studio = binding.etStudio.text.toString()


            )

            db.collection("users")
                .document(currentUserId!!)
                .collection("movies")
                .document(updatedMovie.id)
                .set(updatedMovie)
                .addOnSuccessListener {
                    Toast.makeText(this, "Movie updated!", Toast.LENGTH_SHORT).show()
                    finish()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show()
                }
        }

        binding.btnDelete.setOnClickListener {
            db.collection("users")
                .document(currentUserId!!)
                .collection("movies")
                .document(editingMovie!!.id)
                .delete()
                .addOnSuccessListener {
                    Toast.makeText(this, "Movie deleted!", Toast.LENGTH_SHORT).show()
                    finish()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show()
                }
        }
    }
}
