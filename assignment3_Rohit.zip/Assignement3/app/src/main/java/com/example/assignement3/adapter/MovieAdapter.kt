package com.example.assignement3.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.assignement3.R
import com.example.assignement3.databinding.ItemMovieBinding
import com.example.assignement3.model.Movie
import com.example.assignement3.ui.EditMovieActivity

class MovieAdapter(
    private var movieList: List<Movie>,
    private val onFavoriteClick: (Movie) -> Unit,
    private val onEditClick: (Movie) -> Unit,
    private val onDeleteClick: (Movie) -> Unit
) : RecyclerView.Adapter<MovieAdapter.MovieViewHolder>() {

    inner class MovieViewHolder(val binding: ItemMovieBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        val binding = ItemMovieBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MovieViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        val movie = movieList[position]
        val context = holder.itemView.context

        holder.binding.tvTitle.text = movie.title
        holder.binding.tvStudioRating.text = "Studio: ${movie.studio}\nRating: ${movie.rating} ★"
        holder.binding.tvGenreYear.text = "${movie.genre} • ${movie.year}"

        val resId = context.resources.getIdentifier(movie.posterUrl, "drawable", context.packageName)
        holder.binding.ivMoviePoster.setImageResource(if (resId != 0) resId else R.drawable.ic_launcher_background)

        val starIcon = if (movie.isFavorite) R.drawable.ic_star else R.drawable.ic_star_border
        holder.binding.ivFavorite.setImageResource(starIcon)

        holder.binding.ivFavorite.setOnClickListener { onFavoriteClick(movie) }
        holder.binding.ivEdit.setOnClickListener {
            val intent = Intent(context, EditMovieActivity::class.java)
            intent.putExtra("movie", movie)
            context.startActivity(intent)
        }
        holder.binding.ivDelete.setOnClickListener { onDeleteClick(movie) }
    }

    override fun getItemCount(): Int = movieList.size

    fun updateList(newList: List<Movie>) {
        movieList = newList
        notifyDataSetChanged()
    }
}
