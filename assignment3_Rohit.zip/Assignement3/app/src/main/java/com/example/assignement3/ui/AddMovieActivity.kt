package com.example.assignement3.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.assignement3.databinding.ActivityAddMovieBinding
import com.example.assignement3.model.Movie
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class AddMovieActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddMovieBinding
    private val db = FirebaseFirestore.getInstance()
    private val currentUserId = FirebaseAuth.getInstance().currentUser?.uid

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddMovieBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSaveMovie.setOnClickListener {
            saveMovie()
        }

        binding.btnCancel.setOnClickListener {
            finish()
        }
    }

    private fun saveMovie() {
        val title = binding.etTitle.text.toString()
        val genre = binding.etGenre.text.toString()
        val year = binding.etYear.text.toString().toIntOrNull() ?: 0
        val studio = binding.etStudio.text.toString()
        val rating = binding.etRating.text.toString().toDoubleOrNull() ?: 0.0
        val posterUrl = binding.etPosterUrl.text.toString()

        if (title.isBlank() || genre.isBlank() || posterUrl.isBlank()) {
            Toast.makeText(this, "Title, Genre, and Poster URL are required.", Toast.LENGTH_SHORT).show()
            return
        }

        val newMovie = Movie(
            title = title,
            genre = genre,
            year = year,
            studio = studio,
            rating = rating,
            posterUrl = posterUrl,
            isFavorite = false
        )

        db.collection("users")
            .document(currentUserId!!)
            .collection("movies")
            .add(newMovie)
            .addOnSuccessListener {
                Toast.makeText(this, "Movie added!", Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to add movie", Toast.LENGTH_SHORT).show()
            }
    }
}
