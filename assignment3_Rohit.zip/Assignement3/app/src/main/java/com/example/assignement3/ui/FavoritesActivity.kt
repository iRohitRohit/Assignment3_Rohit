package com.example.assignement3.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.assignement3.adapter.MovieAdapter
import com.example.assignement3.databinding.ActivityFavoritesBinding
import com.example.assignement3.model.Movie
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class FavoritesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFavoritesBinding
    private lateinit var adapter: MovieAdapter
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val allFavorites = mutableListOf<Movie>()
    private var filteredFavorites = listOf<Movie>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavoritesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = MovieAdapter(
            movieList = allFavorites,
            onFavoriteClick = { selectedMovie ->
                selectedMovie.isFavorite = !selectedMovie.isFavorite
                updateFavoriteStatus(selectedMovie)
            },
            onEditClick = { /* no edit on favorites */ },
            onDeleteClick = { selectedMovie ->
                deleteMovie(selectedMovie)
            }
        )

        binding.recyclerViewFavorites.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewFavorites.adapter = adapter

        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                filterMovies(s.toString())
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        fetchFavoriteMovies()
    }

    private fun fetchFavoriteMovies() {
        val uid = auth.currentUser?.uid ?: return
        db.collection("users")
            .document(uid)
            .collection("movies")
            .whereEqualTo("favorite", true)
            .get()
            .addOnSuccessListener { result ->
                allFavorites.clear()
                for (document in result) {
                    val movie = document.toObject(Movie::class.java).copy(id = document.id)
                    allFavorites.add(movie)
                }
                filterMovies(binding.etSearch.text.toString()) // apply any existing filter
            }
            .addOnFailureListener { e ->
                Log.e("FavoritesActivity", "Failed to fetch favorites", e)
            }
    }

    private fun filterMovies(query: String) {
        filteredFavorites = if (query.isEmpty()) {
            allFavorites
        } else {
            allFavorites.filter { it.title.contains(query, ignoreCase = true) }
        }
        adapter.updateList(filteredFavorites)
    }

    private fun updateFavoriteStatus(movie: Movie) {
        val uid = auth.currentUser?.uid ?: return
        db.collection("users")
            .document(uid)
            .collection("movies")
            .document(movie.id)
            .set(movie)
            .addOnSuccessListener {
                fetchFavoriteMovies()
            }
            .addOnFailureListener {
                Log.e("FavoritesActivity", "Failed to update favorite", it)
            }
    }

    private fun deleteMovie(movie: Movie) {
        val uid = auth.currentUser?.uid ?: return
        db.collection("users")
            .document(uid)
            .collection("movies")
            .document(movie.id)
            .delete()
            .addOnSuccessListener {
                fetchFavoriteMovies()
            }
            .addOnFailureListener {
                Log.e("FavoritesActivity", "Failed to delete favorite", it)
            }
    }
}
