package com.example.assignement3.ui

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.widget.SearchView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.assignement3.adapter.MovieAdapter
import com.example.assignement3.databinding.ActivityMainBinding
import com.example.assignement3.model.Movie
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore



class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: MovieAdapter
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val movies = mutableListOf<Movie>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = MovieAdapter(
            movieList = movies,
            onFavoriteClick = { selectedMovie ->
                selectedMovie.isFavorite = !selectedMovie.isFavorite
                updateFavoriteStatus(selectedMovie)
            },
            onEditClick = { selectedMovie ->
                openEditScreen(selectedMovie)
            },
            onDeleteClick = { selectedMovie ->
                deleteMovie(selectedMovie)
            }
        )

        binding.recyclerViewMovies.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewMovies.adapter = adapter

        binding.fabAddMovie.setOnClickListener {
            startActivity(Intent(this, AddMovieActivity::class.java))
        }

        binding.btnViewFavorites.setOnClickListener {
            startActivity(Intent(this, FavoritesActivity::class.java))
        }

        // 💬 Setup search functionality
        binding.searchView.queryHint = "Search by title"
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean = false

            override fun onQueryTextChange(newText: String?): Boolean {
                filterMovies(newText.orEmpty())
                return true
            }
        })

        // Ensure search text is white
        // Ensure search text is white
        val searchText = binding.searchView.findViewById<android.widget.EditText>(
            androidx.appcompat.R.id.search_src_text
        )
        searchText?.setTextColor(android.graphics.Color.WHITE)
        searchText?.setHintTextColor(android.graphics.Color.GRAY)

        fetchMovies()
    }

    override fun onResume() {
        super.onResume()
        fetchMovies()
    }

    private fun fetchMovies() {
        val uid = auth.currentUser?.uid ?: return

        db.collection("users")
            .document(uid)
            .collection("movies")
            .get()
            .addOnSuccessListener { result ->
                movies.clear()
                for (document in result) {
                    val movie = document.toObject(Movie::class.java).copy(id = document.id)
                    movies.add(movie)
                }
                adapter.updateList(movies)
            }
            .addOnFailureListener { e ->
                Log.e("MainActivity", "Failed to fetch movies", e)
            }
    }

    private fun filterMovies(query: String) {
        val filtered = if (query.isEmpty()) movies else movies.filter {
            it.title.contains(query, ignoreCase = true)
        }
        adapter.updateList(filtered)
    }

    private fun updateFavoriteStatus(movie: Movie) {
        val uid = auth.currentUser?.uid ?: return

        db.collection("users")
            .document(uid)
            .collection("movies")
            .document(movie.id)
            .set(movie)
            .addOnSuccessListener {
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener {
                Log.e("MainActivity", "Failed to update favorite status", it)
            }
    }

    private fun deleteMovie(movie: Movie) {
        val uid = auth.currentUser?.uid ?: return
        db.collection("users")
            .document(uid)
            .collection("movies")
            .document(movie.id)
            .delete()
            .addOnSuccessListener {
                Toast.makeText(this, "Movie deleted", Toast.LENGTH_SHORT).show()
                fetchMovies()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to delete movie", Toast.LENGTH_SHORT).show()
            }
    }

    private fun openEditScreen(movie: Movie) {
        val intent = Intent(this, EditMovieActivity::class.java)
        intent.putExtra("movie", movie)
        startActivity(intent)
    }
}
