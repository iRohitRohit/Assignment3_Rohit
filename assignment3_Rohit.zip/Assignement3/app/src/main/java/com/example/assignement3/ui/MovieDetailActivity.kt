package com.example.assignement3.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.assignement3.databinding.ActivityMovieDetailBinding
import com.example.assignement3.model.Movie
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MovieDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMovieDetailBinding
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private lateinit var movie: Movie

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMovieDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        movie = intent.getSerializableExtra("movie") as Movie

        binding.tvTitle.text = movie.title
        binding.tvDescription.text = "Genre: ${movie.genre}\nDirector: ${movie.director}\nRating: ${movie.rating}"

        binding.btnEditDescription.setOnClickListener {
            binding.tvDescription.isEnabled = true
            binding.btnEditDescription.text = "Save Description"

            binding.btnEditDescription.setOnClickListener {
                // This is just a simulation. You may extend Movie to have a "description" if you want true editing.
                Toast.makeText(this, "Description saved locally (not persisted)", Toast.LENGTH_SHORT).show()
                finish()
            }
        }

        binding.btnDeleteMovie.setOnClickListener {
            db.collection("users")
                .document(auth.currentUser!!.uid)
                .collection("movies")
                .document(movie.id)
                .delete()
                .addOnSuccessListener {
                    Toast.makeText(this, "Movie deleted", Toast.LENGTH_SHORT).show()
                    finish()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Error deleting movie", Toast.LENGTH_SHORT).show()
                }
        }
    }
}
